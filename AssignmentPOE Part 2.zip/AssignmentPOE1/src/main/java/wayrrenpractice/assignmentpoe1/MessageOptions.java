/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class MessageOptions {
 public static void handleMessageOption(int option, String recipient, String message, String hash, String messageID) {
    switch (option) {
        case 1:
            System.out.println("Message sent to: " + recipient);
            break;
        case 2:
            System.out.println("Message stored only.");
            break;
        case 3:
            System.out.println("Message disregarded.");
            break;
        default:
            System.out.println("Invalid option selected.");
    }
}
}
  
    



