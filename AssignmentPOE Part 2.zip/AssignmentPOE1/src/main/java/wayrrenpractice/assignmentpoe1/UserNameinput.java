/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class UserNameinput {
  private String username;
 
 public UserNameinput(String username) { 
  
 this.username = username;
 }
 public boolean isValid() {
     return
 username.contains("_")&& username.length() <= 5;
 }
public String getMessage(){
if(isValid()){
return "Username succesfully captured.";
} else{
return "Username is not correctly formatted.Please ensure it contains an underscore and is no more than 5 characters in length.";
}
}
public String getUsername(){
return username;
}
}