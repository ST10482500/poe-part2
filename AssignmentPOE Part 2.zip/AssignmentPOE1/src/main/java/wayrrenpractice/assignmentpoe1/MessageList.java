/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;
import java.util.ArrayList;
/**
 *
 * @author User
 */
public class MessageList {
   
 private static ArrayList<String> sentMessages = new ArrayList<>();

    public static void addMessage(String message) {
        sentMessages.add(message);
    }

    public static void printMessages() {
        for (String msg : sentMessages) {
            System.out.println(msg);
        }
    }
}
 

