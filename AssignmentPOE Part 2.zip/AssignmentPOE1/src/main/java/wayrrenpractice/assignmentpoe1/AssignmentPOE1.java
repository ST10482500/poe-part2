/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package wayrrenpractice.assignmentpoe1;
/**
 *
 * @author User
 */import java.util.Scanner;
public class AssignmentPOE1 {

    public static void main(String[] args) {
      
   Scanner scanner = new Scanner(System.in);
    boolean registrationSuccess = false;
    
    String savedUsername = "";
    String savedPassword = "";
    String firstName = "";
    String lastName = "";
    
    while(!registrationSuccess)
    { 
        System.out.println("Enter your first name:");
    firstName = scanner.nextLine();
    
        System.out.println("Enter your last name:");
    lastName = scanner.nextLine();
    
        System.out.println("Enter your Username:");
    savedUsername = scanner.nextLine();
    UserNameinput usernameInput = new UserNameinput(savedUsername);
    
        System.out.println(usernameInput.getMessage());
    
    System.out.println("Enter your Password:");
    savedPassword = scanner.nextLine();
    PasswordInput passwordInput = new PasswordInput(savedPassword);
       
    System.out.println(passwordInput.getMessage());
    
        System.out.println("Enter Cellphone Number:");
    String phone = scanner.nextLine();
    PhoneInput phoneInput= new PhoneInput(phone);
    
        System.out.println(phoneInput.getMessage());
    
    registrationSuccess = usernameInput.isValid()&& passwordInput.isValid() &&phoneInput.isValid();
        System.out.println("----------------------------------");
    }
    //Simulate Login
    boolean loginSuccess = false;
    
    while(!loginSuccess){
    
        System.out.println("Please login below:");
        
        System.out.println("Username:");
        String loginUsername = scanner.nextLine();
        
        System.out.println("Password:");
        String loginPassword = scanner.nextLine();
    
    if(loginUsername.equals(savedUsername) && loginPassword.equals(savedPassword))
    {
    
    
        System.out.println("Welcome " + firstName + " " + lastName + ",it is great to see you again!");
    
   loginSuccess = true;
    }else{
    
        System.out.println("Username or password is incorrect.Please try again.");
    }
        System.out.println("----------------------------------");
    }

      // PART 2: Message processing
        int messageCount = 0;
        boolean running = true;

        while (running) {
            System.out.print("Enter recipient phone number: ");
            String recipient = scanner.nextLine();
            if (!RecipientValidator.isValidRecipient(recipient)) {
                System.out.println("Recipient number is incorrectly formatted. Try again.\n");
                continue;
            }

            System.out.print("Enter your message: ");
            String message = scanner.nextLine();
            String lengthCheck = MessageValidator.isValidLength(message);
            if (!lengthCheck.equals("valid")) {
                System.out.println(lengthCheck);
                continue;
            }

            String messageID = MessageIDGenerator.generateMessageID(messageCount + 1);
            String messageHash = MessageHashGenerator.createMessageHash(message);

            System.out.println("Message ID: " + messageID);
            System.out.println("Message Hash: " + messageHash);

            System.out.println("Select option: 1 - Send, 2 - Store, 3 - Disregard");
            int option = Integer.parseInt(scanner.nextLine());
            MessageOptions.handleMessageOption(option, messageID, recipient, message, messageHash);
            
            if (option == 1) {
                MessageTracker.incrementMessages();
            }

            System.out.println("Total messages sent: " + MessageTracker.getTotalMessages());

            System.out.print("Continue? (y/n): ");
            String cont = scanner.nextLine();
            if (cont.equalsIgnoreCase("n")) {
                running = false;
            }
        }

        System.out.println("\nAll messages this session:");
        MessageList.printMessages();
        System.out.println("Goodbye.");
    }
}

    


    


    
    
    
    
