/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class MessageHashGenerator {
public static String createMessageHash(String message) {
        String[] words = message.split(" ");
        StringBuilder hash = new StringBuilder("00:0:");
        for (String word : words) {
            if (word.length() > 0) {
                hash.append(word.toUpperCase().charAt(0));
            }
        }
        return hash.toString();
    }
}


